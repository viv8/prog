package com.googlemaps.dao;

import com.googlemaps.dto.LocationDataDTO;

/** 
 * 
 */
public class LocationDAO {
	/**
	 * Returns the location as {@code LocationDataDTO} object
	 * location is getting from the external web application using web services
	 */
	public LocationDataDTO getLocationData(String location) {
		LocationDataDTO data = new LocationDataDTO();
		data.setLocation(location);
		data.setLatitude(0.0);
		data.setLongitude(0.0);
		data.setFullAdress("loc");
		return data;
	}
}
