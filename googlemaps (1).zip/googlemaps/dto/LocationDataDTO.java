package com.googlemaps.dto;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class LocationDataDTO {
	
	private String location;
	
	private double longitude;
	
	private double latitude;
	
	private String fullAdress;
	
	public String getLocation() {
		return location;
	}
	
	public void setLocation(String location) {
		this.location = location;
	}
	
	public double getLongitude() {
		return longitude;
	}
	
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	
	public double getLatitude() {
		return latitude;
	}
	
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	
	public String getFullAdress() {
		return fullAdress;
	}
	
	public void setFullAdress(String fullAdress) {
		this.fullAdress = fullAdress;
	}
	
	@Override
	public String toString() {
		return "LocationDataDTO [location=" + location + ", longitude=" + longitude + ", latitude=" + latitude
				+ ", fullAdress=" + fullAdress + "]";
	}
}
