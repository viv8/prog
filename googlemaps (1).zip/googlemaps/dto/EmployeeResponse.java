package com.googlemaps.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class EmployeeResponse {
	@XmlElement(name="states-code")
	private int statesCode;
	private String message;
	private String discription;
	
	/**
	 * (Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "EmployeeResponce [statesCode=" + statesCode + ", message=" + message + ", discription=" + discription
				+ "]";
	}
	/**
	 * @return the statesCode
	 */
	public int getStatesCode() {
		return statesCode;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @return the discription
	 */
	public String getDiscription() {
		return discription;
	}

	/**
	 * @param statesCode the statesCode to set
	 */
	public void setStatesCode(int statesCode) {
		this.statesCode = statesCode;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @param discription the discription to set
	 */
	public void setDiscription(String discription) {
		this.discription = discription;
	}
}
