package com.googlemaps.rest.services;

import java.util.Set;

import javax.ws.rs.Consumes;
import javax.ws.rs.CookieParam;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.googlemaps.dao.EmployeeDAO;
import com.googlemaps.dto.Employee;
import com.googlemaps.dto.EmployeeResponse;

@Path("/employee")
@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
public class EmployeeRestServices {
	@GET
	@Path("/readCookie")
	public Response readCookie(@CookieParam("name") String name) {
		return Response.status(200).entity(name).build();
	}
	
	@PUT
	@Path("/create")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public EmployeeResponse createEmployee(Employee e) {

		EmployeeResponse resp = new EmployeeResponse();

		if (e.getEid() != 0) {
			EmployeeDAO dao = new EmployeeDAO();
			dao.createEmployee(e);

			resp.setStatesCode(200);
			resp.setMessage("Successfully created the Employee ...");
		} else {
			resp.setStatesCode(400);
			resp.setMessage("Not created the Employee !!!");
			resp.setDiscription("Emp ID is Missing which is Mandatory ");
		}

		return resp;
	}

	@DELETE
	@Path("/delete")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public EmployeeResponse deleteEmployee(@QueryParam("eid") int eid) {
		EmployeeDAO dao = new EmployeeDAO();
		boolean check = dao.deleteEmployee(dao.readEmployee(eid));
		EmployeeResponse response = new EmployeeResponse();
		if (check) {
			response.setStatesCode(200);
			response.setMessage("Successfully deleted the Employee");
			response.setDiscription("The Employee with eid " + eid + " is deleted");
		} else {
			response.setStatesCode(400);
			response.setMessage("Employee cannot be deleted");
			response.setDiscription("The Employee with eid " + eid + " is not exist");
		}
		return response;
	}

	@GET
	@Path("/read")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Employee readEmployee(@QueryParam("eid") int eid) {
		EmployeeDAO dao = new EmployeeDAO();
		return dao.readEmployee(eid);
	}

	@GET
	@Path("/readall")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Set<Employee> readEmployees() {
		EmployeeDAO dao = new EmployeeDAO();
		return dao.readEmployees();
	}

	@POST
	@Path("/modify")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public EmployeeResponse modifyEmployee(Employee e) {

		EmployeeResponse resp = new EmployeeResponse();

		if (e.getEid() != 0) {
			EmployeeDAO dao = new EmployeeDAO();
			dao.modifyEmployee(e);

			resp.setStatesCode(200);
			resp.setMessage("Successfully Updated the Employee ...");
		} else {
			resp.setStatesCode(400);
			resp.setMessage("Not Updated the Employee !!!");
			resp.setDiscription("Emp ID is Missing which is Mandatory ");
		}

		return resp;
	}
}
