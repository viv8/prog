package com.googlemaps.rest.services;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

@Path("/upload")
public class FileUploadService {
	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public String uploadFile(@FormDataParam("file")InputStream inputStream,
				@FormDataParam("file")FormDataContentDisposition fileDetails) {
		File file = new File("D:/"+fileDetails.getFileName());
		try(FileOutputStream outputStream = new FileOutputStream(file)){
			byte[] b = new byte[inputStream.available()];
			inputStream.read(b);
			outputStream.write(b);
			outputStream.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "File uploaded";
	}
}
