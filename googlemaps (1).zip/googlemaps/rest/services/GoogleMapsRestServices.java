package com.googlemaps.rest.services;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.googlemaps.dao.LocationDAO;
import com.googlemaps.dto.LocationDataDTO;

/**
 * Produces the data for requested location as xml or json or plain text
 */
@Path("/geocode")
public class GoogleMapsRestServices {
	/**
	 * Produces the data in xml format as {@code LocationDataDTO} object
	 */
	@Path("/xml")
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public LocationDataDTO getLocationDataInXml(@QueryParam("location")@DefaultValue("Shimoga")String location) {
		LocationDAO dao = new LocationDAO();
		return dao.getLocationData(location);
	}
	
	/**
	 * Produces the data in json format as {@code LocationDataDTO} object
	 */
	@Path("/json")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public LocationDataDTO getLocationDataInJSon(@QueryParam("location")String location) {
		LocationDAO dao = new LocationDAO();
		return dao.getLocationData(location);
	}
	
	/**
	 * Produces the data in text format as {@code LocationDataDTO} object
	 */
	@Path("/txt")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getLocationDataInText(@QueryParam("location")String location) {
		LocationDAO dao = new LocationDAO();
		return dao.getLocationData(location).toString();
	}
}
