package com.googlemaps.rest.services;

import java.io.File;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

@Path("/download")
public class FileDownloadService {
	@GET
	@Produces("image/png")
	public Response downloadFile() {
		String fileName = "D:/Files/wallpaper.png";
		File file = new File(fileName);
		return Response.ok(file)
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename='image.png'")
				.build();
	}
}
