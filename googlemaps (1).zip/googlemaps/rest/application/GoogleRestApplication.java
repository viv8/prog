package com.googlemaps.rest.application;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import org.glassfish.jersey.media.multipart.MultiPartFeature;

import com.googlemaps.rest.services.EmployeeRestServices;
import com.googlemaps.rest.services.FileDownloadService;
import com.googlemaps.rest.services.FileUploadService;
import com.googlemaps.rest.services.GoogleMapsRestServices;

@ApplicationPath("/api")
public class GoogleRestApplication extends Application {
	@Override
	public Set<Class<?>> getClasses() {
		Set<Class<?>> resources = new HashSet<>();
		resources.add(MultiPartFeature.class);
		resources.add(FileUploadService.class);
		resources.add(FileDownloadService.class);
		resources.add(EmployeeRestServices.class);
		resources.add(GoogleMapsRestServices.class);
		
		return resources;
	}
	@Override
	public Set<Object> getSingletons() {
		Set<Object> resources = new HashSet<>();
		resources.add(new MultiPartFeature());
		resources.add(new FileUploadService());
		resources.add(new FileDownloadService());
		resources.add(new EmployeeRestServices());
		resources.add(new GoogleMapsRestServices());
		
		return resources;
	}
}
